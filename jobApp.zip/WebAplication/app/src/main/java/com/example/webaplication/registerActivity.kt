package com.example.webaplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView

class registerActivity : AppCompatActivity() {

    private lateinit var btnregisterUser: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)

        setContentView(R.layout.activity_register)






        btnregisterUser =findViewById(R.id.btnregisterUser)

        val back= findViewById<TextView>(R.id.btnregisterUser )
        back.setOnClickListener{
            val  myIntent =Intent(this,AccountActivity2::class.java)
            startActivity(myIntent)
            back.movementMethod=LinkMovementMethod.getInstance()

        }


        val actionBar =supportActionBar
        actionBar!!.title =""
        actionBar.setDisplayHomeAsUpEnabled(true)

    }
}