package com.example.webaplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.*
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    private val SPLASH_SCREEN : Long =5000

    //    variables
    private lateinit var topanimation:Animation
    private lateinit var bottomanimation:Animation
    private lateinit var image:ImageView
    private lateinit var logo : TextView
    private lateinit var slogan: TextView







    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //removing the title
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar
        setContentView(R.layout.activity_main)

        //animation


        topanimation =AnimationUtils.loadAnimation(this,R.anim.top_animation)
        bottomanimation =AnimationUtils.loadAnimation(this,R.anim.bottom_animatiom)

//        hook
        image =findViewById(R.id.imageView)
        logo =  findViewById(R.id.textView)
        slogan =findViewById(R.id.textView2)


        image.animation =topanimation
        slogan.animation=bottomanimation
        logo.animation=bottomanimation


        Handler().postDelayed({
                              startActivity(Intent(this,AccountActivity2::class.java))
            finish()


        },SPLASH_SCREEN)




    }
}