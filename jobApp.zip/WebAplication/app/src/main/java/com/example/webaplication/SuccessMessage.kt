package com.example.webaplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SuccessMessage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_success_message)
    }
}