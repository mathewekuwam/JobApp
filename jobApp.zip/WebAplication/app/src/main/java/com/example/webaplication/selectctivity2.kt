package com.example.webaplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView

class selectctivity2 : AppCompatActivity() {
    private lateinit var btno: Button
    private lateinit var btnp: Button





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_selectctivity2)





        btno =findViewById(R.id.btno)

        val continu= findViewById<TextView>(R.id.btno )
        continu.setOnClickListener{
            val  myIntent = Intent(this,setpassword::class.java)
            startActivity(myIntent)
            continu.movementMethod= LinkMovementMethod.getInstance()

        }

//
        btnp =findViewById(R.id.btn)

        val select= findViewById<TextView>(R.id.btn )
        select.setOnClickListener{
            val  myIntent = Intent(this,SuccessMessage::class.java)
            startActivity(myIntent)
            select.movementMethod= LinkMovementMethod.getInstance()

        }



    }
}