package com.example.webaplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.content.Intent
import android.text.SpannableString
import android.text.method.LinkMovementMethod
import android.view.View
import android.widget.TextView


class AccountActivity2 : AppCompatActivity() {

    private lateinit var getRegistered: TextView
    private lateinit var tvtext: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN)

        setContentView(R.layout.activity_account2)


        getRegistered =findViewById(R.id.getRegistered)

        val register= findViewById<TextView>(R.id.getRegistered )
        register.setOnClickListener{
            val  myIntent =Intent(this,registerActivity::class.java)
            startActivity(myIntent)
            register.movementMethod=LinkMovementMethod.getInstance()

        }



        tvtext =findViewById(R.id.tvtext)

        val forget= findViewById<TextView>(R.id.tvtext )
        forget.setOnClickListener{
            val  myIntent =Intent(this,ForgotpasswordActivity::class.java)
            startActivity(myIntent)
            forget.movementMethod=LinkMovementMethod.getInstance()

        }



    }

}