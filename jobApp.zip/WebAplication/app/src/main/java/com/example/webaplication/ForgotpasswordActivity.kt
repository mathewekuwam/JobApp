package com.example.webaplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.widget.Button
import android.widget.TextView

class ForgotpasswordActivity : AppCompatActivity() {

    private  lateinit var btn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgotpassword)

        val actionBar =supportActionBar
        actionBar!!.title =""
        actionBar.setDisplayHomeAsUpEnabled(true)




        btn =findViewById(R.id.btn)

        val continueone= findViewById<TextView>(R.id.btn )
        continueone.setOnClickListener{
            val  myIntent =Intent(this,selectctivity2::class.java)
            startActivity(myIntent)
            continueone.movementMethod=LinkMovementMethod.getInstance()

        }

    }
}